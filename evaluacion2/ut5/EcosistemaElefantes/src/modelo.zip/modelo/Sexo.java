package modelo;

public enum Sexo {
    M, H
};
