package modelo;

public interface Animable {
	
	public void accion();
}
