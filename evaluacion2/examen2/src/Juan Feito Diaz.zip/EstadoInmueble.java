public enum EstadoInmueble {
    SE_VENDE, SE_ALQUILA, VENDIDO, ALQUILADO
}
