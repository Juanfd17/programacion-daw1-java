public interface Subvencionales {
    double getPrecioSubvencionado();
}
