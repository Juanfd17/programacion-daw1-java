public class Main {
    public static void main(String[] args) {
    Academia a = new Academia(5);

        Cursos t1 = new Teoricos("t1", 62,12,true);
        Cursos t2 = new Teoricos("t2", 72,6,false);
        Cursos p1 = new Practico("p1", 42,8, "sede1");
        Cursos m1 = new Mixtos("m1", 62,14,7,8);
        Cursos m2 = new Mixtos("m2", 32,10,4,6);

        System.out.println(a.anadirCurso(t1));
        System.out.println(a.anadirCurso(p1));
        System.out.println(a.anadirCurso(m1));
        System.out.println(a.anadirCurso(m2));
        System.out.println(a.anadirCurso(t2));
        System.out.println(a.anadirCurso(m1));

        a.monstrarCursos();

        System.out.println(a.compararCursos(m1,m2));

        a.monstrarCursos();
        System.out.println(a.borrarCurso(m1));
        System.out.println(a.borrarCurso(m2));
        a.monstrarCursos();

        System.out.println(a.anadirCurso(t1));

        a.cursosOficiales();
        a.cursosPorHoras();
        a.cursoMasLargoYMasCorto();
        a.cursosBaratos();
    }
}